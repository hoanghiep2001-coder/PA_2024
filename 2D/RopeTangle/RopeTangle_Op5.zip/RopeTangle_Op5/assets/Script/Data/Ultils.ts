import { Constants } from "./constants";

const { ccclass, property } = cc._decorator;


const TouchArea = {

}

export class Ultils {

   static TouchArea: typeof TouchArea = TouchArea;

}