"use strict";
cc._RF.push(module, '4c7cf9rDSJL36cJtz1lUze/', 'AudioManager');
// Script/Plugin/AudioManager.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var constants_1 = require("../Data/constants");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var AudioManager = /** @class */ (function (_super) {
    __extends(AudioManager, _super);
    function AudioManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // sound 
        _this.bgSound = null;
        _this.openDoorSound = null;
        _this.knockDoorSound = null;
        _this.screamSound = null;
        _this.crySound = null;
        _this.woaAnimeSound = null;
        _this.clickSound = null;
        return _this;
    }
    AudioManager.prototype.playSound = function (soundName) {
        if (constants_1.Constants.ironSource.SoundState) {
            switch (soundName) {
                case "bgSound":
                    this.bgSound.play();
                    break;
                case "openDoorSound":
                    this.openDoorSound.play();
                    break;
                case "clickSound":
                    this.clickSound.play();
                    break;
                case "knockDoorSound":
                    this.knockDoorSound.play();
                    break;
                case "screamSound":
                    this.screamSound.play();
                    break;
                case "crySound":
                    this.crySound.play();
                    break;
                case "woaAnimeSound":
                    this.woaAnimeSound.play();
                    break;
                default:
                    break;
            }
        }
    };
    AudioManager.prototype.switchVolume = function (soundName, volume) {
        switch (soundName) {
            case "bgSound":
                this.bgSound.volume = volume;
                break;
            case "openDoorSound":
                this.openDoorSound.volume = volume;
                break;
            case "clickSound":
                this.clickSound.volume = volume;
                break;
            case "knockDoorSound":
                this.knockDoorSound.volume = volume;
                break;
            case "screamSound":
                this.screamSound.volume = volume;
                break;
            case "crySound":
                this.crySound.volume = volume;
                break;
            case "woaAnimeSound":
                this.woaAnimeSound.volume = volume;
                break;
            default:
                break;
        }
    };
    AudioManager.prototype.stopSound = function (soundName) {
        switch (soundName) {
            case "bgSound":
                this.bgSound.stop();
                break;
            case "openDoorSound":
                this.openDoorSound.stop();
                break;
            case "clickSound":
                this.clickSound.stop();
                break;
            case "knockDoorSound":
                this.knockDoorSound.stop();
                break;
            case "screamSound":
                this.screamSound.stop();
                break;
            case "crySound":
                this.crySound.stop();
                break;
            case "woaAnimeSound":
                this.woaAnimeSound.stop();
                break;
            default:
                break;
        }
    };
    AudioManager.prototype.stopAllSound = function () {
        this.bgSound.stop();
        this.openDoorSound.stop();
        this.knockDoorSound.stop();
        this.screamSound.stop();
        this.crySound.stop();
        this.woaAnimeSound.stop();
        this.clickSound.stop();
    };
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "bgSound", void 0);
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "openDoorSound", void 0);
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "knockDoorSound", void 0);
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "screamSound", void 0);
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "crySound", void 0);
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "woaAnimeSound", void 0);
    __decorate([
        property(cc.AudioSource)
    ], AudioManager.prototype, "clickSound", void 0);
    AudioManager = __decorate([
        ccclass
    ], AudioManager);
    return AudioManager;
}(cc.Component));
exports.default = AudioManager;

cc._RF.pop();