function gameStart() {
    console.log("Game start");
}
function gameClose() {
    console.log("Game end");
}