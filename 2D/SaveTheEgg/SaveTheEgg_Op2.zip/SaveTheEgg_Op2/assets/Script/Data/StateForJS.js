const { ccclass, property } = cc._decorator;
export class StateForJs {
    static isCanDraw = true;
}