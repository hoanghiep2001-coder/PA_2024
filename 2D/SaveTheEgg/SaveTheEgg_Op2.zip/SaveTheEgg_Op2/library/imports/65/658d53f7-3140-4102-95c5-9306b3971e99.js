"use strict";
cc._RF.push(module, '658d5P3MUBBApXFkwazlx6Z', 'StateForJS');
// Script/Data/StateForJS.js

"use strict";

exports.__esModule = true;
exports.StateForJs = void 0;
var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

var StateForJs = function StateForJs() {};

exports.StateForJs = StateForJs;
StateForJs.isCanDraw = true;

cc._RF.pop();