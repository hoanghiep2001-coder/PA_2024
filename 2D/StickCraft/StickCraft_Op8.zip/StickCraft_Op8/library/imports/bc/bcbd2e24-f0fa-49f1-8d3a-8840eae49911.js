"use strict";
cc._RF.push(module, 'bcbd24k8PpJ8Y06iEDq5JkR', 'FGP_Op11');
// Script/FakeGamePlay/FGP_Op11.js

"use strict";

var GameInfo = require("../Const/GameInfo");

var AudioManager = require("AudioManager");

var GameController = require("GameController");

cc.Class({
  "extends": cc.Component,
  properties: {
    AudioManager: AudioManager,
    GameController: GameController,
    cardsToPick: {
      "default": [],
      type: [cc.Node],
      serializable: true
    },
    card_choose1: {
      "default": null,
      type: cc.Node,
      serializable: true
    },
    card_choose2: {
      "default": null,
      type: cc.Node,
      serializable: true
    },
    StepOne: {
      "default": null,
      type: cc.Node,
      serializable: true
    },
    StepTwo: {
      "default": null,
      type: cc.Node,
      serializable: true
    },
    pickedCard: null,
    IsFirstCardOpen: false,
    IsSecondCardOpen: false
  },
  start: function start() {
    // this.AudioManager.introSound.play();
    GameInfo.currentOption === 11 && this.registerEvent();
  },
  registerEvent: function registerEvent() {
    var _this = this;

    this.cardsToPick.forEach(function (card, index) {
      card.on(cc.Node.EventType.TOUCH_START, function () {
        return _this.handleCardTouchStart(card, index);
      }, _this);
    });
  },
  handleCardTouchStart: function handleCardTouchStart(card, index) {
    if (this.IsSecondCardOpen) return;
    var currentCard = card;

    if (this.pickedCard !== currentCard.name) {
      !this.IsFirstCardOpen ? this.handleStepOne(index, card) : this.handleShowStepTwo(index, card);
    }

    this.pickedCard = currentCard._name;
    this.GameController.handlePlaySoundIronSource();
  },
  handleStepOne: function handleStepOne(index, card) {
    this.IsFirstCardOpen = true;
    this.AudioManager.clickSound.play();
    var currentCardPos = card.getPosition();
    this.card_choose2.setPosition(currentCardPos);
    cc.tween(this.card_choose2).to(0.5, {
      opacity: 255
    }).start();
  },
  handleShowStepTwo: function handleShowStepTwo(index, card) {
    var _this2 = this;

    this.IsSecondCardOpen = true;
    this.AudioManager.clickSound.play();
    GameInfo.TutorialDoneStage1 = true;
    var currentCardPos = card.getPosition();
    this.card_choose1.setPosition(currentCardPos);
    cc.tween(this.card_choose1).to(0.5, {
      opacity: 255
    }).start();

    if (this.IsFirstCardOpen && this.IsSecondCardOpen) {
      this.scheduleOnce(function () {
        _this2.stepOneAnimFade();

        _this2.mergeCard();
      }, 1);
    }
  },
  stepOneAnimFade: function stepOneAnimFade() {
    cc.tween(this.StepOne).to(0.5, {
      opacity: 0
    }).start();
  },
  mergeCard: function mergeCard() {
    var _this3 = this;

    var MergingScene = this.StepTwo.getChildByName("Merging");
    var spine_speedLine = this.StepTwo.getChildByName("SpeedLine_1");
    var fx_Fusion = MergingScene.getChildByName("FX_Fusion");
    var cardWhite = MergingScene.getChildByName("card_white");
    var card1 = MergingScene.getChildByName("Card1");
    var card2 = MergingScene.getChildByName("Card2");
    var spine_angry = MergingScene.getChildByName("Angry");
    fx_Fusion.active = true;
    cc.tween(this.StepTwo).to(0.5, {
      opacity: 255
    }).call(function () {
      return fusion();
    }).start();

    var fusion = function fusion() {
      _this3.scheduleOnce(function () {
        _this3.AudioManager.introSound.stop();

        _this3.AudioManager.tuhuSound.play();

        MergingScene.getComponent(cc.Animation).play();

        _this3.scheduleOnce(function () {
          spine_speedLine.getComponent(sp.Skeleton).timeScale = 1.1;

          _this3.AudioManager.FusionSound.play();

          cardWhite.active = true;
          spine_angry.active = true;
          card1.active = false;
          card2.active = false;
          fx_Fusion.active = false;
        }, 1);

        _this3.scheduleOnce(function () {
          cc.tween(cardWhite).to(1, {
            scale: 5
          }).call(function () {
            GameInfo.isDoneMergeCard = true;
            GameInfo.currentOption = 10;
            GameInfo.isChosenCharacter = true;
            spine_speedLine.active = false;

            _this3.AudioManager.bgSound.play();

            _this3.hideThisComponent();
          }).start();
          spine_angry.active = false;
          cc.log("Done Fusion");
        }, 4);
      }, 1);
    };
  },
  hideThisComponent: function hideThisComponent() {
    var _this4 = this;

    cc.tween(this.node).to(1, {
      opacity: 0
    }).call(function () {
      return _this4.node.active = false;
    }).start();
  }
});

cc._RF.pop();