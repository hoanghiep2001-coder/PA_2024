"use strict";
cc._RF.push(module, '3c1e5m3SxlExru99RiMp/tN', 'EnemyCollisionAttack');
// Script/Enemy/EnemyCollisionAttack.js

"use strict";

var Player3D = require("Player3D");

var _require = require("GameEnum"),
    EnEnemies = _require.EnEnemies;

var CONST = require("CONST");

var GameInfo = require("../Const/GameInfo");

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {},
  start: function start() {},
  update: function update(dt) {},
  onEnable: function onEnable() {
    this.scheduleOnce(function () {
      this.disableCollision();
    }, 0.15);
  },
  disableCollision: function disableCollision() {
    this.node.active = false;
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    if (other.node.group == "Player") {
      var zombieParentNode = this.node.parent.parent,
          EnemyBehaviorComp = zombieParentNode.getComponent("EnemyBehavior"); // setup dame Boss for op 9

      if (EnemyBehaviorComp.EnemyId == EnEnemies.Boss && GameInfo.currentOption === 9) {
        this.setUpDameEnemyForOp9(other);
        return;
      } // setup dame boss for op 10
      // if(EnemyBehaviorComp.EnemyId == EnEnemies.Boss && GameInfo.currentOption === 10) {
      //     this.setUpDameEnemyForOp9(other);
      // CONST.ZombieBaseAttack = 60;
      // return;
      // }
      // Basic Dame For Enemy


      CONST.ZombieBaseAttack = 60;
      other.getComponent(Player3D).hit(CONST.ZombieBaseAttack);
    }
  },
  setUpDameEnemyForOp9: function setUpDameEnemyForOp9(other) {
    CONST.ZombieBaseAttack = 300;
    other.getComponent(Player3D).hit(CONST.ZombieBaseAttack);
  }
});

cc._RF.pop();