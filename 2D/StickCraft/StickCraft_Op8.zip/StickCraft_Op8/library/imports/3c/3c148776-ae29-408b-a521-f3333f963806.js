"use strict";
cc._RF.push(module, '3c148d2rilAi6Uh8zM/ljgG', 'TreasureCollision');
// Script/Treasure/TreasureCollision.js

"use strict";

var GameInfo = require("../Const/GameInfo");

cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    if (other.node.group == "Player" && GameInfo.isDefeatBoss) {
      cc.log("Treasure Touched!");
      GameInfo.isTouchTreasure = true;
      this.node.active = false; // this.AudioManger.levelUpSound.play();
    }
  }
});

cc._RF.pop();