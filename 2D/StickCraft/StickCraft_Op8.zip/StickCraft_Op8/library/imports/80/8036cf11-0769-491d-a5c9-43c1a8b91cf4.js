"use strict";
cc._RF.push(module, '8036c8RB2lJHaXJQ8GouRz0', 'Boss');
// Script/Enemy/Boss.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    isBoss: false
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();