cc.Class({
    extends: cc.Component,

    properties: {
        isBoss: false
    },

    // onLoad () {},

    start () {
        
    },

    // update (dt) {},
});
