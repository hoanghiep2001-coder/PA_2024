"use strict";
cc._RF.push(module, '3b838rchfZDZ7EUO6w1VHtd', 'CircleEnums');
// Script/MainGame/CircleEnums.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipeCircle = exports.typeColorCircle = void 0;
var typeColorCircle;
(function (typeColorCircle) {
    typeColorCircle[typeColorCircle["blue"] = 0] = "blue";
    typeColorCircle[typeColorCircle["green"] = 1] = "green";
    typeColorCircle[typeColorCircle["orange"] = 2] = "orange";
    typeColorCircle[typeColorCircle["reed"] = 3] = "reed";
    typeColorCircle[typeColorCircle["violet"] = 4] = "violet";
    typeColorCircle[typeColorCircle["yellow"] = 5] = "yellow";
})(typeColorCircle = exports.typeColorCircle || (exports.typeColorCircle = {}));
var tipeCircle;
(function (tipeCircle) {
    tipeCircle[tipeCircle["normal"] = 0] = "normal";
    tipeCircle[tipeCircle["lightningHorizont"] = 1] = "lightningHorizont";
    tipeCircle[tipeCircle["lightningVertical"] = 2] = "lightningVertical";
    tipeCircle[tipeCircle["rainbowBall"] = 3] = "rainbowBall";
})(tipeCircle = exports.tipeCircle || (exports.tipeCircle = {}));

cc._RF.pop();