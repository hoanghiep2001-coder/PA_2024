export enum typeColorCircle {
    blue,
    green,
    orange,
    reed,
    violet,
    yellow,
}

export enum tipeCircle {
    normal,
    lightningHorizont,
    lightningVertical,
    rainbowBall,
}