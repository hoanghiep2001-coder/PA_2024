export enum typeColorCircle {
    red,
    yellow,
    green,
    purple,
    blue,
    orange,
}

export enum tipeCircle {
    normal,
    lightningHorizont,
    lightningVertical,
    rainbowBall,
}