enum typeCell {
    normal = 0,
    franzy,
}

enum typeColor {
    gray = 0,
    white,
}