
require('./assets/Script/Data/Ultils');
require('./assets/Script/Data/constants');
require('./assets/Script/MainGame/Cell');
require('./assets/Script/MainGame/CellEnums');
require('./assets/Script/MainGame/Circle');
require('./assets/Script/MainGame/CircleEnums');
require('./assets/Script/MainGame/ClassHelpers');
require('./assets/Script/MainGame/GameField');
require('./assets/Script/MainGame/GamesController');
require('./assets/Script/Plugin/AudioManager');
require('./assets/Script/Plugin/Responsive');
