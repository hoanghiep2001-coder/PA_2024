
## `Lưu ý game Thieft`
- Sử dụng vị trí để bắt điểm vẽ sẽ tốt hơn sử dụng va chạm
- sử dụng graphics để nối 2 điểm A và C lại với nhau, từ đó tạo ra đường kẻ