

const checkMergeFirstStep = () => {
    
}

const TouchArea = {
    checkMergeFirstStep: checkMergeFirstStep,
}


export class Utils {

    static TouchArea = TouchArea;
}

