"use strict";
module.exports = {
    description: "将构建的Web项目打包成一个html",
    open_panel: "super html",
};