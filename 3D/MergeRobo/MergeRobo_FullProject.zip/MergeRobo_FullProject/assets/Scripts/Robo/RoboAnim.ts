


export class RoboAnim {
    static Idle: string = "idle";
    static Walk: string = "walk";
    static Atk: string = "atk";
    static Pickup: string = "pickup";
    static Die: string = "die";
}